import { InteractionRequiredAuthError, PublicClientApplication } from "@azure/msal-browser";
import { loginRequest, msalConfig } from "../config/auth";
import { isPlatform } from "@ionic/react";

export const msalInstance = new PublicClientApplication(msalConfig);

const obj = {
  "token_type": "Bearer",
  "scope": "User.Read MailboxSettings.Read Calendars.ReadWrite openid profile",
  "expires_in": 3600,
  "ext_expires_in": 3600,
  "access_token": "EwCIA8l6BAAUbDba3x2OMJElkF7gJ4z/VbCPEz0AASmD/WB0pi+oOs8A31yIHycDQ+I/QANLrFMGgYjs8pfKzBKzJk7Nqeix6U20YY2nWvF8nNK6m5TA1mtGi4XJ7OG24iwVGMw2MSPgknhxTmFgti4YbBMA0AFW4tUpUaXN2fIwvE3veRMUZkjYmdllOOomS6Ql6uYNc85zqAqk3cl3oXOJAHM5b7aNV4fkM65Lrr1RrjgWVEOM+eW2zt+N/Mmf4sA83J5Yc07HdgwgKxLLKo1dA8CmdnhRUKWllNZ+OLVZp3dV5iC1BKh94odYZS0v0GzzCrUqCQI0eo0EY+FzAdsVuzLQDkWAjCwLDBnjOF0SUr8hpMAUGFvhIXR1WFkQZgAAEKJ0GwVP87BzQPgIDu8nGHJQAiZK3QT/eVF02bLPgeLY2v7X11wUokxBeOOB5RZxCbINVTzNH4NgDd9fZym5tFocwa35aNB8iw+26EE7WVKDMhcohbVgmCohQd+yeOzwYW/xhtDDTxOaO5OdXtlZq2WP7481S/Cs35SdmZ98g0xPo9NOXMINRp/ub/Qind6ixmOCvfdoqzRlzev/wFbvr6pOBKL7i+k2PXgWs+M67ckysBEmsMXCuNYc/kvv8h9QcLk7TgnUElbGJdPgJ0XEjl5+mcZTyyVnZgMIhZVAYxmEjKEvj/axnIlSwtMpTcDZKKPRz7x5s15ONyYsmxtI+agAtT2GJt7xr2ISKUTX8kTZmMJ2Vji5suEKSOwThrPJfJEHKP0tnhvMBddTZn6luToAMZcao5Hr6F3jhlvx+oS0lwshRbkCXtdwjG2D2/Ua/VjYUYKL7sTH9MJ6U8LuiokcQjigJ3CwrqMw7MY1fPBpCe2a7xnIeTz3iUZtr2HvDIaNg5In4gY2k8KAxfi7rZhC6Io7VnkFPqRNul+CAwRhylzRHrEVCTQxiGEd6UhoRvBBDy6APBthHer1/zNuxTKh+BBaYMqOzzolSrlm5DG55sq1eOTT9XfuKnVNIE6EpYT7HilC18btYnP3afemEJMjEDuibl5HkKYgutK5EP7GD3TzmeMlsBbbbN6fdYVd5HhFwlJJ0AGTuwZojExrUkuYaRc2NR/V2+8XRUNCTalk0S+yMkyj19tqpTxBCQZPcsFLvXfpWrc1dV+KXQDInU7BeW5WFhbiMD31b2ibgS184kGWAg==",
  "refresh_token": "M.C528_BAY.0.U.-Cm7Ub559sFqv6ReCBysjAOirv*IDtyZ!EhIUOaMo8cC8rgR0uMnWo03MhCJYnZyeVGRgH!u33ztQpY3Pz3TWfOm3ioCjDqLaawVDJ4p2lIDhPJWipM6*0FfjpFtmDXDVGuMOvuzNnCOsskV!wxantCO2b9Or1vtObDeq14XBoFVGRW!EOJS*O2wVMUyYcTzRr2hHZpbzT1zEhroXwyKduOtSjUSq0JkJcxccvjomGBkVmZScTO172UJE0m78GOr31f9R!O2raTUaOLxfzPvPjMtqPhWG!*r43KJRWtPlmQmu9Tybl1u9Gvy9flqFGPUHwCdYecI29Vs1VNlx91OJyJ1xYz9WIKxGAoEgOiDefPetT!UFAq65ziszDwWBzuelhXo2ycN2upmJpjgc!fq7nGE$",
  "id_token": "eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiIsImtpZCI6Ik0xQ2FEWFA2NmkwU2JEZ3pLVzhIRTBKRkwtMCJ9.eyJ2ZXIiOiIyLjAiLCJpc3MiOiJodHRwczovL2xvZ2luLm1pY3Jvc29mdG9ubGluZS5jb20vOTE4ODA0MGQtNmM2Ny00YzViLWIxMTItMzZhMzA0YjY2ZGFkL3YyLjAiLCJzdWIiOiJBQUFBQUFBQUFBQUFBQUFBQUFBQUFGVG8xOWI5U0VDTXhJUzVSNGZsRkp3IiwiYXVkIjoiNzIxMDNkZWUtNjQ2Zi00Yjc1LTg5OGItMDY2NWFlOGFjYmM4IiwiZXhwIjoxNzIzMDUzMTgzLCJpYXQiOjE3MjI5NjY0ODMsIm5iZiI6MTcyMjk2NjQ4MywibmFtZSI6IlNodWJoYW0gQ2hvYmRhciIsInByZWZlcnJlZF91c2VybmFtZSI6InNodWJoYW1jaG9iZGFyMjAwMUBnbWFpbC5jb20iLCJvaWQiOiIwMDAwMDAwMC0wMDAwLTAwMDAtOWMwNi05MDE5NjUyMzEyZWUiLCJ0aWQiOiI5MTg4MDQwZC02YzY3LTRjNWItYjExMi0zNmEzMDRiNjZkYWQiLCJub25jZSI6ImY2NmM4NzQzLWRhYmQtNDg4Yi05NTIxLTdkNTk1NjM3NzA1MyIsImFpbyI6IkRnUSpUbXNmQ05FOUo4VVpXYkhmZnp0VFVlWWxFTVdDdUt0QUVVVWowNWdFd09SKm5KdGFuMTkwbkNmaHlHNmdiMWFuSzlVRFhhdmg2YkN2YXJZS2pteipEUlR3MlA3MmFXdENSNEphSG11alR5cmtGWUR5YTU2QVVJY2ZWVTNkIThyb1hncFB5Mmd1bTc2WDVFdjFSZ3kyRkc4N1JvTDkwOHE0Nko3MURIS20ifQ.h4OGJ4F4EejMCDSP6AXPjXkJOGT6H0s15V8xz1EBNQyHg2CXH6R7-W9uvDEvbuXAb8G3TmCkx6V_mSvnfcq-7rBOKcq_VjEuB0r9aVKQVTKPueAgjqyLIOYKX7LoncKmzF9J35aWeMoYzXMzUpgGeE4TP0bTIYm9EWDGhtPg_Vj1PVvprP66WdoeFdO13TBLQjSQj1G3BBy9QUwbEjZ-H4_Gr7jkgYMakZy8t1Mk_N2Hzs2od9_7Jq1OMJrRE9eg9TiKRD_UGKIuUSzWMMmY7uhc5CIEpCwkiXJi3Ffs8xu246UFu_XT97bFodqwS7i54XJsBSoqo-bMzQ41ZOtPkA",
  "client_info": "eyJ2ZXIiOiIxLjAiLCJzdWIiOiJBQUFBQUFBQUFBQUFBQUFBQUFBQUFGVG8xOWI5U0VDTXhJUzVSNGZsRkp3IiwibmFtZSI6IlNodWJoYW0gQ2hvYmRhciIsInByZWZlcnJlZF91c2VybmFtZSI6InNodWJoYW1jaG9iZGFyMjAwMUBnbWFpbC5jb20iLCJvaWQiOiIwMDAwMDAwMC0wMDAwLTAwMDAtOWMwNi05MDE5NjUyMzEyZWUiLCJ0aWQiOiI5MTg4MDQwZC02YzY3LTRjNWItYjExMi0zNmEzMDRiNjZkYWQiLCJob21lX29pZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC05YzA2LTkwMTk2NTIzMTJlZSIsInVpZCI6IjAwMDAwMDAwLTAwMDAtMDAwMC05YzA2LTkwMTk2NTIzMTJlZSIsInV0aWQiOiI5MTg4MDQwZC02YzY3LTRjNWItYjExMi0zNmEzMDRiNjZkYWQifQ"
};

export const getAccessToken = async () => {
  return obj.access_token
  await msalInstance.initialize();
  const accounts = msalInstance.getAllAccounts();
  if (accounts.length > 0) {
    const response = await msalInstance.acquireTokenSilent({
      ...loginRequest,
      account: accounts[0]
    });
    return response.accessToken;
  } else {
    const response = await msalInstance.loginPopup({
      scopes: loginRequest.scopes
    });
    if (isPlatform('capacitor')) {
      const acc = await msalInstance.handleRedirectPromise();
      console.log(acc)
      alert(acc?.accessToken)
      return acc?.accessToken
    }
    return response.accessToken;
  }
};

export const silentUpdateToken = async() => {
  const request = {
    scopes: loginRequest.scopes,
    account: msalInstance.getAllAccounts()[0],
    forceRefresh: true,
    refreshTokenExpirationOffsetSeconds: 7200 // 2 hours * 60 minutes * 60 seconds = 7200 seconds
  };

  const tokenResponse = await msalInstance.acquireTokenSilent(request).catch(async (error) => {
      if (error instanceof InteractionRequiredAuthError) {
          // fallback to interaction when silent call fails
          await msalInstance.acquireTokenRedirect(request);
      }
  });

}

export const getMsalEvents = async () => {
  const token = await getAccessToken();
  const response = await fetch("https://graph.microsoft.com/v1.0/me/calendars", {
    headers: {
      Authorization: `Bearer ${token}`
    }
  });
  const data = await response.json();
  return data.value;
};

export const getDateEvents = async (startDate:any, endDate:any) => {
  try {
    const token = await getAccessToken();
    const response = await fetch(
      `https://graph.microsoft.com/v1.0/me/calendarview?startDateTime=${startDate}&endDateTime=${endDate}`,
      {
        headers: {
          Authorization: `Bearer ${token}`
        }
      }
    );
    const data = await response.json();
    return data.value;
  }
  catch (error) {
    return error;
  }
  };
