/* eslint-disable */
import PageChatDetail from './PageChatDetail';

export default {
  title: "PageChatDetail",
};

export const Default = () => <PageChatDetail />;

Default.story = {
  name: 'default',
};
